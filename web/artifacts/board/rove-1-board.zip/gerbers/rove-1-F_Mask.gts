%TF.GenerationSoftware,KiCad,Pcbnew,10.0.5-1-g226df246f3*%
%TF.CreationDate,2026-09-05T13:31:38-04:00*%
%TF.ProjectId,rove-1,726f7665-2d31-42e6-9b69-6361645f7063,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5-1-g226df246f3) date 2026-09-05 13:31:38*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
